public class Vaccine {
    private String name;
    private double price;

    public Vaccine(String name, double price) {
        this.name = name;
        this.price = price;
    }
}
